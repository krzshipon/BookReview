package com.cyclicsoft.bookreview;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    ImageButton btGotoAddbook;
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private Recy recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btGotoAddbook = findViewById(R.id.bt_goto_add_book);
        btGotoAddbook.setOnClickListener(view -> {
            Intent addBookIntent = new Intent(MainActivity.this, CreateBookActivity.class);
            startActivity(addBookIntent);
        });


        recyclerView = findViewById(R.id.recycler_view);

        init();
        dos();
        Log.d("Check",  "size" + mAdmins.size());


        mAdapter = new SpeedListAdapter(mAdmins);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Do u want to Sign out?")
                .setMessage("Student will no longer see the Route?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, (arg0, arg1) -> {
                   FirebaseAuth.getInstance().signOut();
                   super.onBackPressed();
                }).create().show();


    }
}

package com.cyclicsoft.bookreview;

public class Constants {
    public static final String TABLE_BOOKS = "books";
    public static final String COLUMN_BTITLE = "title";
    public static final String COLUMN_BAUTHOR = "author";
    public static final String COLUMN_BSUMM = "sum";
    public static final String COLUMN_BURL = "url";
    public static final String COLUMN_ID = "id";
}
